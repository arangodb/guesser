A guessing game that learns
===========================

This web application is a guessing game, in which the computer
tries to guess a thing or animal you think of by asking a series of
questions, for which you provide the answers. Finally, the computer
will try to guess what you thought of. If it is wrong, it tries to
learn from the experience, such that it can be successful the next
time round. 

License
-------

This code is distributed under the 
[Apache License](http://www.apache.org/licenses/LICENSE-2.0).
